<h3>Halo, Pengguna Tes Riasec!</h3>

<p>
	Perihal : Memulihkan Kata Sandi
	<br>
	Tanggal Pemulihan : <?= date('d M Y H:i',strtotime($tanggal)); ?>
	<br><br>
	Berikut adalah informasi seputar akun anda
	<br><br>
	Username : {{$username}} 
	<br>
	Password : {{$password}} 
	<br>

</p>
 
