


<?php $__env->startSection('menu'); ?>
	<ul class="nav nav-primary">
		<li class="nav-item ">
			<a href="/admin">
				<i class="fas fa-home"></i>
				<p>Dashboard</p>
			</a>
		</li>
		<li class="nav-section">
			<span class="sidebar-mini-icon">
				<i class="fa fa-ellipsis-h"></i>
			</span>
			<h4 class="text-section">Data</h4>
		</li>
		<li class="nav-item">
			<a href="/dataprodi">
				<i class="fas fa-id-badge" style="-webkit-transform: rotate(13deg);transform: rotate(13deg);"></i>
				<p>Data Prodi</p>
			</a>
		</li>
		<li class="nav-item active">
			<a href="/datamhs">
				<i class="fas fa-user-friends" style="-webkit-transform: rotate(13deg);transform: rotate(13deg);"></i>
				<p>Data Mahasiswa</p>
			</a>
		</li>
		<li class="nav-item">
			<a href="/datasoal">
				<i class="fas fa-clipboard-list" style="-webkit-transform: rotate(15deg);transform: rotate(15deg);"></i>
				<p>Data Soal</p>
			</a>
		</li>     
		<li class="nav-item">
			<a data-toggle="collapse" href="#tables">
				<i class="fas fa-table"></i>
				<p>Data Hasil</p>
				<span class="caret"></span>
			</a>
			<div class="collapse" id="tables">
				<ul class="nav nav-collapse">
					<?php $__currentLoopData = $mprodi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mpro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li>
						<a href="/prodi:mhs=<?php echo e($mpro->PRODI_ID); ?>">
							<span class="sub-item"><?php echo e($mpro->PRODI); ?></span>
						</a>
					</li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
		</li>
	</ul>
<?php $__env->stopSection(); ?>

	

<?php $__env->startSection('content'); ?>

		
	<div class="content">
		
		<div class="page-inner">
			<div class="page-header">
				<!-- <h4 class="page-title">DataTables</h4> -->
				<ul class="breadcrumbs">
					<li class="nav-home">
						<a href="#">
							<i class="flaticon-home"></i>
						</a>
					</li>
					<li class="separator">
						<i class="flaticon-right-arrow"></i>
					</li>
					<li class="nav-item">
						<a href="#">Data</a>
					</li>
					<li class="separator">
						<i class="flaticon-right-arrow"></i>
					</li>
					<li class="nav-item">
						<a href="#">Data Mahasiswa</a>
					</li>
				</ul>
			</div>
			<div class="row">
				<div class="col-md-12">
					<div class="card">
						<div class="card-header">
							<div class="d-flex align-items-center">
								<h4 class="card-title">Data Mahasiswa</h4>
								<!-- <button class="btn btn-dark btn-round ml-auto" data-toggle="modal" data-target="#addmhs">
									<i class="fa fa-plus-circle"> </i> Tambah data
								</button> -->
							</div>
						</div>
						<div class="card-body">
							<div class="table-responsive">
								<table id="add-row" class="display table table-striped table-hover" >
									<thead>
										<tr>
											<th style="text-align: center">NIM</th>
											<!-- <th>genEGORI</th> -->
											<th style="text-align: center">Nama</th>
											<th style="text-align: center">Email</th>
											<th style="text-align: center">Username</th>
											<th style="text-align: center">No Ponsel</th>
											<th style="text-align: center;">Aksi</th>
										</tr>
									</thead>
									<style type="text/css">
										tbody tr td{
											padding: -30px;
										}
									</style>
									<tbody>
										<?php $__currentLoopData = $mhs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mhs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<tr>
											<td style="width: 10px;"><?php echo e($mhs->NIM); ?></td>
											<td><?php echo e($mhs->NAMA); ?></td>
											<td><?php echo e($mhs->EMAIL); ?></td>
											<td style="text-align: center"><?php echo e($mhs->USERNAME); ?></td>
											<td style="text-align: center"><?php echo e($mhs->NO_PONSEL); ?></td>
											<td style="text-align: center; width: 70px;">
												<a class="btn btn-warning btn-round ml-auto btn-sm" data-toggle="modal" data-target="#edit<?php echo e($mhs->USER_ID); ?>" style="color: white;">
													<i class="fa fa-pencil-alt" style="margin: -3px;"></i>
												</a>
												<a href="/mhs:del=<?php echo e($mhs->USER_ID); ?>" onclick="return confirm('Apakah anda yakin akan menghapus data mahasiswa ini? ');"class="btn btn-danger btn-round ml-auto btn-sm" style="color: white;">
													<i class="fa fa-trash" style="margin: -3px;"></i>
												</a>
											</td>
										</tr>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</tbody>
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>

			

		<?php $__currentLoopData = $emhs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="modal fade" id="edit<?php echo e($emh->USER_ID); ?>" tabindex="-1" role="dialog" aria-hidden="true">
				<div class="modal-dialog modal-lg" role="document">
					<div class="modal-content">
						<div class="modal-header no-bd">
							<h5 class="modal-title">
								<span class="fw-mediumbold">
								Edit Mahasiswa</span>
							</h5>
						</div>

						<?php 

							$edit = DB::SELECT("select * from pengguna a, mhs b where a.USER_ID = b.USER_ID and a.USER_ID = '$emh->USER_ID'");

							foreach($edit as $upd){
						?>
						<form action="/mhs:upd=<?php echo e($upd->USER_ID); ?>" method="post" enctype="multipart/form-data">
		                    <?php echo e(csrf_field()); ?>

						<div class="modal-body">
								<div class="row">
									<input type="hidden" name="id" value="<?php echo e($upd->USER_ID); ?>" readonly="">
									
									
									<div class="col-sm-6">
										<div class="form-group form-group-default">
											<label>Nama Lengkap</label>
											<input type="text" name="nama" class="form-control" value="<?php echo e($upd->NAMA); ?>" required="" autocomplete="off">
										</div>
									</div>
									<div class="col-sm-6">
										<div class="form-group form-group-default">
											<label>No Induk Mahasiswa</label>
											<input type="number" name="nim" class="form-control" value="<?php echo e($upd->NIM); ?>" required="" autocomplete="off">
										</div>
									</div>
									
									<div class="col-sm-6">
										<div class="form-group form-group-default">
											<label>Email</label>
											<input type="text" name="email" class="form-control" value="<?php echo e($upd->EMAIL); ?>" required="" autocomplete="off">
										</div>
									</div>
									<div class="col-sm-6">
										<div class="form-group form-group-default">
											<label>Program Studi</label>
											<select class="form-control" name="prodi" required="">
												<?php $__currentLoopData = $prodi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						                          	<?php if ($pr->PRODI_ID == $upd->PRODI_ID){ ?>
						                               <option value="<?php echo e($pr->PRODI_ID); ?>" selected=""><?php echo e($pr->PRODI); ?></option>
						                            <?php }else{ ?>
						                              <option value="<?php echo e($pr->PRODI_ID); ?>"><?php echo e($pr->PRODI); ?></option>
						                            <?php }?>
						                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						                    </select>
										</div>
									</div>
									<div class="col-sm-6">
										<div class="form-group form-group-default">
											<label>Username</label>
											<input type="text" name="user" class="form-control" value="<?php echo e($upd->USERNAME); ?>" required="" autocomplete="off">
										</div>
									</div>
									<div class="col-sm-6">
										<div class="form-group form-group-default">
											<label>Gender</label>
											<select class="form-control" name="gend" required="">
												<?php $__currentLoopData = $gen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ge): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						                          	<?php if ($ge == $upd->GENDER){ ?>
						                               <option value="<?php echo e($ge); ?>" selected=""><?php echo e($ge); ?></option>
						                            <?php }else{ ?>
						                              <option value="<?php echo e($ge); ?>"><?php echo e($ge); ?></option>
						                            <?php }?>
						                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						                    </select>
										</div>
									</div>
									
									<div class="col-sm-6">
										<div class="form-group form-group-default">
											<label>Password</label>
											<input type="text" name="pass" class="form-control" value="<?php echo e($upd->PASSWORD); ?>" required="" autocomplete="off">
										</div>
									</div>
									<div class="col-sm-6">
										<div class="form-group form-group-default">
											<label>No Ponsel</label>
											<input type="number" name="telp" class="form-control" value="<?php echo e($upd->NO_PONSEL); ?>" required="" autocomplete="off">
										</div>
									</div>
									
								</div>
						</div>
						<div class="modal-footer no-bd">
							<button type="button" class="btn btn-danger btn-round" data-dismiss="modal"><i class="fa fa-times-circle"></i> Batal</button>
							<button class="btn btn-dark btn-round"><i class="fa fa-check-circle"></i> Ubah</button>
						</div>
						</form>
						<?php } ?>
					</div>
				</div>
			</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


		</div>
	</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layadm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\tesria\resources\views//admin/dta_mhs.blade.php ENDPATH**/ ?>