


<?php $__env->startSection('menu'); ?>
	<ul class="nav nav-primary">  
		<li class="nav-item ">
			<a href="/admin">
				<i class="fas fa-home"></i>
				<p>Dashboard</p>
			</a>
		</li>
		<li class="nav-section">
			<span class="sidebar-mini-icon">
				<i class="fa fa-ellipsis-h"></i>
			</span>
			<h4 class="text-section">Data</h4>
		</li>
		<li class="nav-item">
			<a href="/dataprodi">
				<i class="fas fa-id-badge" style="-webkit-transform: rotate(13deg);transform: rotate(13deg);"></i>
				<p>Data Prodi</p>
			</a>
		</li>
		<li class="nav-item">
			<a href="/datamhs">
				<i class="fas fa-user-friends" style="-webkit-transform: rotate(13deg);transform: rotate(13deg);"></i>
				<p>Data Mahasiswa</p>
			</a>
		</li>
		<li class="nav-item">
			<a href="/datasoal">
				<i class="fas fa-clipboard-list" style="-webkit-transform: rotate(15deg);transform: rotate(15deg);"></i>
				<p>Data Soal</p>
			</a>
		</li>     
		<li class="nav-item active submenu">
			<a data-toggle="collapse" href="#tables">
				<i class="fas fa-table"></i>
				<p>Data Hasil</p>
				<span class="caret"></span>
			</a>
			<div class="collapse" id="tables">
				<ul class="nav nav-collapse">
						<?php $__currentLoopData = $mprodi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mpro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php if ($mpro->PRODI_ID == $idpro){ ?>
								<li class="active">
									<a href="/prodi:mhs=<?php echo e($mpro->PRODI_ID); ?>">
										<span class="sub-item"><?php echo e($mpro->PRODI); ?></span>
									</a>
								</li>
							<?php }else{ ?>
								<li>
									<a href="/prodi:mhs=<?php echo e($mpro->PRODI_ID); ?>">
										<span class="sub-item"><?php echo e($mpro->PRODI); ?></span>
									</a>
								</li>
							<?php }?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
		</li>
	</ul>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

		
	<div class="content">
		
		<div class="page-inner">
			<div class="page-header">
				<!-- <h4 class="page-title">DataTables</h4> -->
				<ul class="breadcrumbs">
					<li class="nav-home">
						<a href="#">
							<i class="flaticon-home"></i>
						</a>
					</li>
					<li class="separator">
						<i class="flaticon-right-arrow"></i>
					</li>
					<li class="nav-item">
						<a href="#">Data</a>
					</li>
					<li class="separator">
						<i class="flaticon-right-arrow"></i>
					</li>
					<li class="nav-item">
						<a href="#">Data Hasil Tes</a>
					</li>
				</ul>
			</div>
			<div class="row">	
				<div class="col-md-12">
					<?php if(Session::get('kosong')){ ?>
		        		<div class="alert alert-danger alert-dismissible fade show" role="alert" style="border-radius: 5px;">
						  <strong style="margin-right: 10px;">Mohon Maaf!!</strong>  Data yang anda cetak kosong
						  <button type="button" class="close" data-dismiss="alert" aria-label="Close" style="margin-top: -11px;">
						    <span aria-hidden="true">&times;</span>
						  </button>
						</div>
					<?php }else{ ?>
						
					<?php }?>
	        	</div>
				<div class="col-md-9">
					<div class="card">
						
						<div class="card-body">
							<div class="table-responsive">
								<table id="add-row" class="display table table-striped table-hover">
									<thead>
										<tr>
											<th style="text-align: center">NIM</th>
											<th style="text-align: center">Nama</th>
											<th style="text-align: center">Karakter</th>
											<!-- <th style="text-align: center">Tanggal</th> -->
											<th style="text-align: center">Reset</th>
										</tr>
									</thead>
									<style type="text/css">
										tbody tr td{
											padding: -30px;
										}
									</style>
									<tbody>
										<?php $__currentLoopData = $hmhs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detmhs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<tr>
											<td style="width: 10px;"><?php echo e($detmhs->NIM); ?></td>
											<td><?php echo e($detmhs->NAMA); ?></td>
											<td style="text-align: center"><?php echo e($detmhs->KARAKTER); ?></td>
											<!-- <td style="text-align: center"> <?= date('d M Y',strtotime($detmhs->TGL)); ?> </td> -->
											
											<td style="text-align: center;width: 10%;">
												<a href="/hasil:res=<?php echo e($detmhs->NIM); ?>" onclick="return confirm('Apakah anda yakin akan mereset hasil  mahasiswa ini? ');" style="color: red;">
													<i class="fa fa-redo-alt"></i>
												</a>
											</td>
										</tr>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</tbody>
								</table>
							</div>
						</div>

					</div>
				</div>

				<div class="col-md-3">
							<div class="card card-profile">
								
								<div class="card-header" style="padding-bottom: -15px;">
									<center>
									<div class="name" style="font-size: 18px;"><?php $__currentLoopData = $prodi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($prod->PRODI); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div>
									<br>
									
									<div class="number"><?php $__currentLoopData = $jmhs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jmh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($jmh->jum); ?> Mahasiswa <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div>
									</center>
								</div>
								<div class="card-body">
									<div class="user-profile text-center">
										
										
										<!-- <div class="job">Frontend Developer</div> -->
										<div class="desc" style="margin-top:-25px;">
											<canvas id="mychart" height="250px"></canvas>
										</div>
									</div>
								</div>
								<div class="card-footer">
									<div class="row user-stats text-center">
										<?php $__currentLoopData = $sql; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tampil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<div class="col-md-9">
											<div class="number" style="text-align: left;"><?php echo e($tampil->kar); ?></div>
											<!-- <div class="title">Jurusan</div> -->
										</div>
										<div class="col-md-3">
											<!-- <div class="number"><?php echo e($tampil->hasil); ?></div> -->
											<div class="title">
												<?php if($tampil->hasil == null): ?>
													
													<span style="color:lightgrey;">0</span>
												
												<?php else: ?>
													
													<?php echo e($tampil->hasil); ?>

												
												<?php endif; ?>
											</div>
										</div>

										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</div>
								</div>

							</div>
						</div>

			</div>

		</div>
	</div>

<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.3.0/Chart.bundle.js"></script>
<script type="text/javascript">
	

var chartData = [<?php foreach($sql as $ju){?>{"visitor": '<?php echo $ju->per; ?>', "visit": '<?php echo $ju->kar; ?>'}, <?php } ?>]

var visitorData = [],
    sum = 0,
    visitData = [];

for (var i = 0; i < chartData.length; i++) {
    visitorData.push(chartData[i]['visitor'])
    visitData.push(chartData[i]['visit'])
  
    sum += chartData[i]['visitor'];
}

var textInside = sum.toString();

var myChart = new Chart(document.getElementById('mychart'), {
    type: 'doughnut',
    animation:{
        animateScale:true
    },
    data: {
        labels: visitData,
        datasets: [{
            label: 'Visitor',
            data: visitorData,
            backgroundColor: [
                "#142850",
                "#27496D",
                "#0C7B93",
                "#00A8CC",
                "#3282B8",
                "#b3dfe7",
                "#BBE1FA"
            ]
        }]
    },
    options: {
        elements: {
          center: {
            text: textInside
          }
        },
        responsive: true,
        legend: false,
        tooltips: {
             enabled: true,
             mode: 'label',
             callbacks: {
                label: function(tooltipItem, data) {
                    var indice = tooltipItem.index;
                    return  data.labels[indice] + " : " + data.datasets[0].data[indice] + '%';
                }
             }
         },
    }
});


</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layadm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\tesria\resources\views//admin/dta_hasil.blade.php ENDPATH**/ ?>