<h3>Halo, Pengguna Tes Riasec!</h3>

<p>
	Perihal : Memulihkan Kata Sandi
	<br>
	Tanggal Pemulihan : <?= date('d M Y H:i',strtotime($tanggal)); ?>
	<br><br>
	Berikut adalah informasi seputar akun anda
	<br><br>
	Username : <?php echo e($username); ?> 
	<br>
	Password : <?php echo e($password); ?> 
	<br>

</p>
 
<?php /**PATH D:\xampp\htdocs\tesria\resources\views/email/email_pass.blade.php ENDPATH**/ ?>