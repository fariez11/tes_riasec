


<?php $__env->startSection('menu'); ?>
	<ul class="nav nav-primary">
		<li class="nav-item">
			<a href="/admin">
				<i class="fas fa-home"></i>
				<p>Dashboard</p>
			</a>
		</li>
		<li class="nav-section">
			<span class="sidebar-mini-icon">
				<i class="fa fa-ellipsis-h"></i>
			</span>
			<h4 class="text-section">Data</h4>
		</li>
		<li class="nav-item">
			<a href="/datasoal">
				<i class="fas fa-clipboard-list" style="-webkit-transform: rotate(15deg);transform: rotate(15deg);"></i>
				<p>Data Soal</p>
			</a>
		</li>
		<li class="nav-item">
			<a href="/dataprodi">
				<i class="fas fa-id-badge" style="-webkit-transform: rotate(13deg);transform: rotate(13deg);"></i>
				<p>Data Prodi</p>
			</a>
		</li>
		<li class="nav-item active">
			<a data-toggle="collapse" href="#tables1">
				<i class="fas fa-user-friends" style="-webkit-transform: rotate(15deg);transform: rotate(15deg);"></i>
				<p>Data Mahasiswa</p>
				<span class="caret"></span>
			</a>
			<div class="collapse" id="tables1">
				<ul class="nav nav-collapse">
					<?php $__currentLoopData = $mprodi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mpro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if ($mpro->KODE == $idpro){ ?>
							<li class="active">
								<a href="/mhs:prodi=<?php echo e($mpro->KODE); ?>">
									<span class="sub-item"><?php echo e($mpro->PRODI); ?></span>
								</a>
							</li>
						<?php }else{ ?>
							<li>
								<a href="/mhs:prodi=<?php echo e($mpro->KODE); ?>">
									<span class="sub-item"><?php echo e($mpro->PRODI); ?></span>
								</a>
							</li>
						<?php }?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
		</li>
		<li class="nav-item">
			<a data-toggle="collapse" href="#tables2">
				<i class="fas fa-table"  style="-webkit-transform: rotate(15deg);transform: rotate(15deg);"></i>
				<p>Data Hasil</p>
				<span class="caret"></span>
			</a>
			<div class="collapse" id="tables2">
				<ul class="nav nav-collapse">
					<?php $__currentLoopData = $mprodi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mpro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li>
						<a href="/prodi:mhs=<?php echo e($mpro->KODE); ?>">
							<span class="sub-item"><?php echo e($mpro->PRODI); ?></span>
						</a>
					</li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
		</li>
	</ul>
<?php $__env->stopSection(); ?>

	

<?php $__env->startSection('content'); ?>

		
	<div class="content">
		
		<div class="page-inner">
			<div class="page-header">
				<!-- <h4 class="page-title">DataTables</h4> -->
				<ul class="breadcrumbs">
					<li class="nav-home">
						<a href="#">
							<i class="flaticon-home"></i>
						</a>
					</li>
					<li class="separator">
						<i class="flaticon-right-arrow"></i>
					</li>
					<li class="nav-item">
						<a href="#">Data</a>
					</li>
					<li class="separator">
						<i class="flaticon-right-arrow"></i>
					</li>
					<li class="nav-item">
						<a href="#">Data Mahasiswa</a>
					</li>
					<li class="separator">
						<i class="flaticon-right-arrow"></i>
					</li>
					<li class="nav-item">
						<a href="#"><?php $__currentLoopData = $sespro; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($sep->PRODI); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></a>
					</li>
				</ul>
			</div>
			<div class="row">
				<div class="col-md-12">
					<div class="card">
						<div class="card-header">
							<div class="d-flex align-items-center">
								<h4 class="card-title">Data Mahasiswa Program Studi <?php $__currentLoopData = $sespro; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($sep->PRODI); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></h4>
								
							</div>
						</div>
						<div class="card-body">
							<form action="<?php echo e(('/imp_mhs')); ?>" method="post" enctype="multipart/form-data">
							<?php echo e(csrf_field()); ?>

							<div class="row">
								<div class="col-sm-3">
									<div class="form-group">
										<label for="email2">Import File</label>
										<input type="file" name="file" class="form-control">
										
										<span style="color:red;margin-top: -10px;">ekstensi file : .xlsx </span>
									</div>
									<br>
								</div>
								
								<div class="col-sm-4">
									<div class="form-group">
										<label for="email2">Prodi</label>
										<select class="form-control" name="prodi" required="">
											<option></option>
											<?php $__currentLoopData = $prodi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($pro->KODE); ?>"> <?php echo e($pro->PRODI); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</select>
									</div>
								</div>	
								<div class="col-sm-3" style="padding-top: 37px;">
									<button class="btn btn-dark"><i class="fas fa-file-import" ></i> Import</button>
								</div>	
								<div class="col-sm-2" style="padding-top: 37px;">
									 <a class="btn btn-dark ml-auto" data-toggle="modal" data-target="#addmhs" style="color: white;">
										<i class="fa fa-plus-circle"> </i> Tambah data
									</a>
								</div>	
							</div>
							</form>
							<div class="table-responsive">
								<table id="add-row" class="display table table-striped table-hover" >
									<thead>
										<tr>
											<th style="text-align: center">#</th>
											<th style="text-align: center">NIM</th>
											<th style="text-align: center">Nama</th>
											<th style="text-align: center">Email</th>
											<th style="text-align: center">Gender</th>
											<!-- <th style="text-align: center">Username</th> -->
											<th style="text-align: center;">Aksi</th>
										</tr>
									</thead>
									<style type="text/css">
										tbody tr td{
											padding: -30px;
										}
									</style>
									<tbody>
										<?php $no = 1; ?>
										<?php $__currentLoopData = $emhs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<tr>
											<td style="width: 5px;"><?php echo e($no++); ?></td>
											<td style="width: 10px;"><?php echo e($dat->NIM); ?></td>
											<td><?php echo e($dat->NAMA); ?></td>
											<td><?php echo e($dat->EMAIL); ?></td>
											<td><?php echo e($dat->GENDER); ?></td>
											<!-- <td style="text-align: center"><?php echo e($dat->USERNAME); ?></td> -->
											<td style="text-align: center; width: 110px;">
												<a class="btn btn-info btn-round ml-auto btn-sm" data-toggle="modal" data-target="#det<?php echo e($dat->NIM); ?>" style="color: white;">
													<i class="fa fa-info" style="margin: -0.5px;"></i>
												</a>
												<a class="btn btn-warning btn-round ml-auto btn-sm" data-toggle="modal" data-target="#edit<?php echo e($dat->NIM); ?>" style="color: white;">
													<i class="fa fa-pencil-alt" style="margin: -3px;"></i>
												</a>
												<a href="/mhs:del=<?php echo e($dat->NIM); ?>" onclick="return confirm('Apakah anda yakin akan menghapus data mahasiswa ini? ');"class="btn btn-danger btn-round ml-auto btn-sm" style="color: white;">
													<i class="fa fa-trash" style="margin: -3px;"></i>
												</a>
											</td>
										</tr>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</tbody>
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>

		</div>
	</div>


	<div class="modal fade" id="addmhs" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header no-bd">
                    <h5 class="modal-title">
                        <span class="fw-mediumbold">
                        Tambah Mahasiswa</span>
                    </h5>
                    <!-- <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button> -->
                </div>
                <form action="<?php echo e(url('/add_mhs')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                <div class="modal-body">
                    <div class="row">
                        
                        <div class="col-md-6">

                            <div class="form-group form-group-default">
                                <label>Nama</label>
                                <input type="text" name="nama" class="form-control" placeholder="Ahmad Abdul" autocomplete="off" required="">
                            </div>
                            <div class="form-group form-group-default">
                                <label>Email</label>
                                <input type="email" name="email" class="form-control" placeholder="emailanda@gmail.com" autocomplete="off" required="">
                            </div>
                            <div class="form-group form-group-default">
                                <label>Username</label>
                                <input type="text" name="user" class="form-control" placeholder="admin" autocomplete="off" required="">
                            </div>
                            <div class="form-group form-group-default">
                                <label>Password</label>
                                <input type="text" name="pass" class="form-control" placeholder="admin" autocomplete="off" required="">
                            </div>

                        </div>
                        <div class="col-md-6">

                            <div class="form-group form-group-default">
                                <label>Nama Program Studi</label>
                                <select class="form-control" name="prodi" required="">
                                    <option></option>
                                    <?php $__currentLoopData = $prodi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($prd->KODE); ?>"><?php echo e($prd->PRODI); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group form-group-default">
                                <label>Nomer Induk Mahasiswa</label>
                                <input type="number" name="nim" class="form-control"  placeholder="36XXXXXXXXXX" min="360000000000" autocomplete="off" required="">
                            </div>
                            
                            <div class="form-group form-group-default">
                                <label>Gender</label>
                                <select class="form-control" name="gend" required="">
                                    <option></option>
                                    <?php $__currentLoopData = $gen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ge): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option><?php echo e($ge); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group form-group-default">
                                <label>Nomer Ponsel</label>
                                <input type="number" name="no" class="form-control" placeholder="089XXXXXXX" autocomplete="off" required="">
                            </div>

                        </div>
                        
                    </div>
                </div>
                <div class="modal-footer no-bd">
                    <button  type="button" class="btn btn-danger btn-round" data-dismiss="modal"><i class="icon icon-close"></i> Batal</button>
                    <button class="btn btn-dark btn-round"><i class="icon icon-check"></i> Simpan</button>
                </div>
                </form>
            </div>
        </div>
    </div>


	<?php $__currentLoopData = $emhs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div class="modal fade" id="det<?php echo e($emh->NIM); ?>" tabindex="-1" role="dialog" aria-hidden="true">
		<div class="modal-dialog modal-md" role="document">
			<div class="modal-content">
				<div class="modal-header no-bd">
					<h5 class="modal-title">
						<span class="fw-mediumbold">
						Detail Mahasiswa</span>
					</h5>
				</div>

				<?php 

					$edit = DB::SELECT("SELECT * FROM mhs b, prodi c WHERE b.KODE = c.KODE AND b.NIM = '$emh->NIM'");

					foreach($edit as $upd){
				?>
				<form action="/mhs:upd=<?php echo e($upd->NIM); ?>" method="post" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

				<div class="modal-body">
						<div class="row">
							<input type="hidden" name="id" value="<?php echo e($upd->NIM); ?>" readonly="">
							
							<div class="col-md-12">

								<style>
									table tr td{
										padding: 10px;
									}
								</style>
								<table>
									<tr>
										<td>Nomor Induk Mahasiswa</td>
										<td>:</td>
										<td><?php echo e($upd->NIM); ?></td>
									</tr>
									<tr>
										<td>Nama Lengkap</td>
										<td>:</td>
										<td><?php echo e($upd->NAMA); ?></td>
									</tr>
									<tr>
										<td>Email</td>
										<td>:</td>
										<td><?php echo e($upd->EMAIL); ?></td>
									</tr>
									<tr>
										<td>Username</td>
										<td>:</td>
										<td><?php echo e($upd->USERNAME); ?></td>
									</tr>
									<tr>
										<td>Password</td>
										<td>:</td>
										<td><?php echo e($upd->PASSWORD); ?></td>
									</tr>
									<tr>
										<td>Program Studi</td>
										<td>:</td>
										<td><?php echo e($upd->PRODI); ?></td>
									</tr>
									<tr>
										<td>Gender</td>
										<td>:</td>
										<td><?php echo e($upd->GENDER); ?></td>
									</tr>
									<tr>
										<td>No Ponsel</td>
										<td>:</td>
										<td><?php echo e($upd->NO_PONSEL); ?></td>
									</tr>
								</table>
							</div>
							
						</div>
				</div>
				<div class="modal-footer no-bd">
					<button type="button" class="btn btn-dark btn-round" data-dismiss="modal"><i class="fa fa-times-circle"></i> Tutup</button>
				</div>
				</form>
				<?php } ?>
			</div>
		</div>
	</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



	<?php $__currentLoopData = $emhs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="modal fade" id="edit<?php echo e($emh->NIM); ?>" tabindex="-1" role="dialog" aria-hidden="true">
			<div class="modal-dialog modal-lg" role="document">
				<div class="modal-content">
					<div class="modal-header no-bd">
						<h5 class="modal-title">
							<span class="fw-mediumbold">
							Edit Mahasiswa</span>
						</h5>
					</div>

					<?php 

						$edit = DB::SELECT("SELECT * FROM mhs WHERE NIM = '$emh->NIM'");

						foreach($edit as $upd){
					?>
					<form action="/mhs:upd=<?php echo e($upd->NIM); ?>" method="post" enctype="multipart/form-data">
	                    <?php echo e(csrf_field()); ?>

					<div class="modal-body">
							<div class="row">
								<input type="hidden" name="id" value="<?php echo e($upd->NIM); ?>" readonly="">
								
								
								<div class="col-sm-6">
									<div class="form-group form-group-default">
										<label>Nama Lengkap</label>
										<input type="text" name="nama" class="form-control" value="<?php echo e($upd->NAMA); ?>" required="" autocomplete="off">
									</div>
								</div>
								<div class="col-sm-6">
									<div class="form-group form-group-default">
										<label>No Induk Mahasiswa</label>
										<input type="number" name="nim" class="form-control" value="<?php echo e($upd->NIM); ?>" required="" autocomplete="off">
									</div>
								</div>
								
								<div class="col-sm-6">
									<div class="form-group form-group-default">
										<label>Email</label>
										<input type="text" name="email" class="form-control" value="<?php echo e($upd->EMAIL); ?>" required="" autocomplete="off">
									</div>
								</div>
								<div class="col-sm-6">
									<div class="form-group form-group-default">
										<label>Program Studi</label>
										<select class="form-control" name="prodi" required="">
											<?php $__currentLoopData = $prodi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					                          	<?php if ($pr->KODE == $upd->KODE){ ?>
					                               <option value="<?php echo e($pr->KODE); ?>" selected=""><?php echo e($pr->PRODI); ?></option>
					                            <?php }else{ ?>
					                              <option value="<?php echo e($pr->KODE); ?>"><?php echo e($pr->PRODI); ?></option>
					                            <?php }?>
					                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					                    </select>
									</div>
								</div>
								<div class="col-sm-6">
									<div class="form-group form-group-default">
										<label>Username</label>
										<input type="text" name="user" class="form-control" value="<?php echo e($upd->USERNAME); ?>" required="" autocomplete="off">
									</div>
								</div>
								<div class="col-sm-6">
									<div class="form-group form-group-default">
										<label>Gender</label>
										<select class="form-control" name="gend" required="">
											<?php $__currentLoopData = $gen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ge): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					                          	<?php if ($ge == $upd->GENDER){ ?>
					                               <option value="<?php echo e($ge); ?>" selected=""><?php echo e($ge); ?></option>
					                            <?php }else{ ?>
					                              <option value="<?php echo e($ge); ?>"><?php echo e($ge); ?></option>
					                            <?php }?>
					                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					                    </select>
									</div>
								</div>
								
								<div class="col-sm-6">
									<div class="form-group form-group-default">
										<label>Password</label>
										<input type="text" name="pass" class="form-control" value="<?php echo e($upd->PASSWORD); ?>" required="" autocomplete="off">
									</div>
								</div>
								<div class="col-sm-6">
									<div class="form-group form-group-default">
										<label>No Ponsel</label>
										<input type="number" name="telp" class="form-control" value="<?php echo e($upd->NO_PONSEL); ?>" required="" autocomplete="off">
									</div>
								</div>
								
							</div>
					</div>
					<div class="modal-footer no-bd">
						<button type="button" class="btn btn-danger btn-round" data-dismiss="modal"><i class="fa fa-times-circle"></i> Batal</button>
						<button class="btn btn-dark btn-round"><i class="fa fa-check-circle"></i> Ubah</button>
					</div>
					</form>
					<?php } ?>
				</div>
			</div>
		</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layadm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\tes_riasec\resources\views//admin/dta_mhs.blade.php ENDPATH**/ ?>