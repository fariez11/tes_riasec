


<?php $__env->startSection('menu'); ?>
	<ul class="nav nav-primary">
		<li class="nav-item">
			<a href="/admin">
				<i class="fas fa-home"></i>
				<p>Dashboard</p>
			</a>
		</li>
		<li class="nav-section">
			<span class="sidebar-mini-icon">
				<i class="fa fa-ellipsis-h"></i>
			</span>
			<h4 class="text-section">Data</h4>
		</li>		
		<li class="nav-item active">
			<a href="/soal">
				<i class="fas fa-clipboard-list" style="-webkit-transform: rotate(15deg);transform: rotate(15deg);"></i>
				<p>Data Soal</p>
				<!-- <span class="caret"></span> -->
			</a>
		</li>
	</ul>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>

		
			<div class="content">
				
				<div class="page-inner">
					<div class="col-md-3 pl-md-0 pr-md-0">
						<div class="card-pricing2 card-info">
							<div class="pricing-header">
								<h3 class="fw-bold">Tes Riasec</h3>
								<!-- <span class="sub-title">Tes Riasec</span> -->
							</div>
							<div class="price-value">
								<div class="value">
									<!-- <span class="currency">$</span> -->
									<!-- <span class="amount">20.<span>99</span></span> -->
									<span class="amount"><i class="fas fa-clipboard-list fa-lg" style="-webkit-transform: rotate(15deg);transform: rotate(15deg);"></i></span>
									<!-- <span class="month">/month</span> -->
								</div>
							</div>
							<ul class="pricing-content">
								<li>60GB Disk Space</li>
								<li>60 Email Accounts</li>
								<li>60GB Monthly Bandwidth</li>
							</ul>
							<a href="/soal" class="btn btn-info btn-border btn-lg w-75 fw-bold mb-3">Sign up</a>
						</div>
					</div>
				</div>

			</div>
			
		

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.laymhs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\tesria\resources\views//mhs/d_soal.blade.php ENDPATH**/ ?>